<?php
include_once PJ_VIEWS_PATH . 'pjFront/elements/layout_1/checkout.php';
?>