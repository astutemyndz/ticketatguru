<fieldset class="fieldset white">
	<legend><?php __('lblChooseTheme'); ?></legend>
	<br/>
	<?php include PJ_VIEWS_PATH . 'pjAdminOptions/elements/theme.php'; ?>
</fieldset>