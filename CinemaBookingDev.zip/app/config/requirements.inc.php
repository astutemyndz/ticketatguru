<?php
return array(
	'function' => array(
		'mail' => 'PHP mail() function is disabled or not installed. For further details please contact your hosting provider.',
	),
	'extension' => array(
		'gd' => 'The GD library is not loaded. For further details please contact your hosting provider.',
	),
	'class' => array(
		//'Imagick' => 'ImageMagick was not found. For further details please contact your hosting provider.',
	),
);